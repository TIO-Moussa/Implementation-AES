package Crypto;

import java.io.File;
import java.security.Key;
import java.security.KeyPair;

import javax.crypto.*;

public interface CryptoInterface {
	final String algo = "AES"; 
	final String algoAsym ="RSA";
	final int taille_cleasym=2048;
	final int taille_cle = 128;
	final byte[] salt = "MO5-°HG3YEH255367gdsjhgd".getBytes();
	final int iteration = 1000;
	final String kdf = "PBKDF2WithHmacSHA1";
	final String transform="AES/CBC/PKCS5Padding";
	final String transformasym="RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
	final String ivString="l3tdsi-2021-2022";//attention 16 caractèresS

	SecretKey generationcle();
	int sauvegardecle (SecretKey key,String path);
	SecretKey recuperercle(String path);
	public SecretKey generationPBKcle(String mdp);
	
	int encrypt(SecretKey k, String inputPath, String outputPath, int mode);
	
	public void crypt(File dir, SecretKey key, int mode);
	public KeyPair generationPaireCle();
}
