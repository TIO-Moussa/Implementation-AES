package Crypto;



import java.security.InvalidKeyException;
import java.security.KeyPair;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;

public class testeasym {
	public static void main(String[] args) {
		CryptoSym cryptos = new CryptoSym();
		try {
			Cipher oaepFromAlgo = Cipher.getInstance(cryptos.transformasym);
			KeyPair kp = cryptos.generationPaireCle();

			oaepFromAlgo.init(Cipher.ENCRYPT_MODE, kp.getPublic());
			byte[] ct = oaepFromAlgo.doFinal("owlstead".getBytes());
			
			oaepFromAlgo.init(Cipher.DECRYPT_MODE, kp.getPrivate());
			byte[] ct1 = oaepFromAlgo.doFinal(ct);
			System.out.println(new String(ct1));
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
}
