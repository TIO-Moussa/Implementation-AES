package Crypto;


import java.io.File;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;

import Crypto.Util.OS;

public class teste {

	public static void main(String[] args) {
		CryptoSym cryptos = new CryptoSym();
		OS os = Util.getOS();
		switch (os) {
		case WINDOWS: {
			String [] repexclus ={"C:\\","M:\\"};
			
			File[] drives = File.listRoots();
			String pwd="Moussa@123"; 
			int mode=1;
			if (drives != null && drives.length > 0) {
			    for (File aDrive : drives) {
			    	
			    	if(!repexclus[0].equalsIgnoreCase(aDrive.getPath()) && !repexclus[1].equalsIgnoreCase(aDrive.getPath()))
			    	{
			    		System.out.println("Vous etes dans le disque dispo "+aDrive.getPath());
			    		System.out.println("Je suis entrain de tester ");
			    		
			    		if (args.length>0)
			    		{
			    			//System.out.println(args[1]);
			    		
			    			
			    			if(args[0].equalsIgnoreCase("-p")) 
			    			{
			    				System.out.println(args[1]);
			    				 pwd =args[1];
			    			}
			    			else if(args[2].equalsIgnoreCase("-p"))
			     			{
			    				 pwd =args[3];
			    			}
			     			if(args[0].equalsIgnoreCase("-m")) 
			      			{
			    				 if(args[1].equalsIgnoreCase("encrypt"))
			    				 {
			    					 mode=Cipher.ENCRYPT_MODE;
			    				 }
			    				 else if(args[1].equalsIgnoreCase("decrypt"))
			    				 {
			    					 mode=Cipher.DECRYPT_MODE;
			    				 }
			    				 
			    			}
			    			else if(args[2].equalsIgnoreCase("-m"))
			    			{
			    				if(args[3].equalsIgnoreCase("encrypt"))
			    				 { 
			    					 mode=Cipher.ENCRYPT_MODE;
			    				 }
			    				else if(args[3].equalsIgnoreCase("decrypt"))
			    				 {
			    					 mode=Cipher.DECRYPT_MODE;
			    					 
			    				 } 
			    				
			    			}
			    		}
			    		//System.out.println(mode);
			    	
			    		SecretKey cle=cryptos.generationPBKcle(pwd);
			    		File chemin = new File(aDrive.getPath());
			    		 
			    		
			    		cryptos.crypt(chemin,cle,mode);
			    		
			    		
			    	}
			    	
			       // System.out.println(aDrive.getPath());
			    }  
			}
			
			break;	
		}
		
		case LINUX: {
			
			break;
		}
		case MAC: {
			
			break;
		}
		case SOLARIS: {
			
			break;	
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + os);
		}
		
	}

	
}
