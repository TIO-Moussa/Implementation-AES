package Crypto;

import java.io.*;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoSym  implements CryptoInterface{

	@Override
	public SecretKey generationcle() {
		try {
			KeyGenerator kg = KeyGenerator.getInstance(algo);
			kg.init(taille_cle);
			return kg.generateKey();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int sauvegardecle(SecretKey key, String path) {
		try {
			FileOutputStream fos = new FileOutputStream(path);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(key);
			oos.close();
			fos.close();
			return 0;
		} catch (IOException e) {
			e.printStackTrace();
			return -1;
		}
	}

	@Override
	public SecretKey recuperercle(String path) {
		try {
			FileInputStream fis = new FileInputStream(path);
			ObjectInputStream ois = new ObjectInputStream(fis);
			return (SecretKey) ois.readObject();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int encrypt(SecretKey k, String inputPath, String outputPath, int mode) {
		try {
			FileInputStream fis = new FileInputStream(inputPath);
			FileOutputStream fos = new FileOutputStream(outputPath);
			Cipher cif = Cipher.getInstance(transform);
			cif.init(mode, k, new IvParameterSpec(ivString.getBytes()));
			CipherInputStream cis = new CipherInputStream(fis,cif);
			byte[] buffer = new byte[4096];
			int nbrByteLus = 0;
			while((nbrByteLus=cis.read(buffer)) != -1) {
				fos.write(buffer, 0,nbrByteLus);
			}
			cis.close();
			fis.close();
			fos.close();
			cif = null;
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return -1;
	}

	

	@Override
	public void crypt(File dir, SecretKey key, int mode) {
		if (dir.isDirectory()) {
			System.out.println(dir.getAbsolutePath());
			File[] list = dir.listFiles();
			for (int i=0;i<list.length;i++) {
				if (list[i].isFile()) {
					if (mode == Cipher.ENCRYPT_MODE) {
						this.encrypt(key, list[i].getAbsolutePath(), list[i].getAbsolutePath()+".cry", mode);
					}
					else {
						String path = list[i].getAbsolutePath().split(".cry")[0];
						this.encrypt(key, list[i].getAbsolutePath(), path, mode);
					}
					//String path = (mode == Cipher.ENCRYPT_MODE):list[i].getAbsolutePath()+".cry"?list[i].getAbsolutePath().split(".cry")[0];
					
					list[i].delete();
				}
				else {
 			 
					 crypt(list[i],key,mode);
 
				  }
			}
		
		}
	}



	@Override
	public SecretKey generationPBKcle(String mdp) {
		SecretKey clepbe = null;
        //on appelle Transforme le mot de passe en tableau de Char
        char[] password = mdp.toCharArray();
        PBEKeySpec pbe = new PBEKeySpec(password, salt, iteration, taille_cle);
        //on vide le tableau de char password
        mdp = "";
	for (int j = 0; j < password.length; j++) {
		password[j] = 0;
	}
	try {  
         //on appelle le KDF: PBEKeySpec pour construire une clé
          SecretKeyFactory kdfFactory = SecretKeyFactory.getInstance(kdf);
          SecretKey keyPBE = kdfFactory.generateSecret(pbe);
          clepbe = new SecretKeySpec(keyPBE.getEncoded(), algo);
			
       } catch (Exception e) {
	     // TODO Auto-generated catch block
	      e.printStackTrace();
       }
                
       return clepbe;
	}

	
	@Override
	public KeyPair generationPaireCle() {
		try {
			KeyPairGenerator kg = KeyPairGenerator.getInstance(algoAsym);
			kg.initialize(taille_cleasym);
			return kg.generateKeyPair();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return null;
	}
}

	


 

